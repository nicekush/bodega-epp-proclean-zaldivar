// ==========================================================================
// Módulo de Ingresos por Factura (Entradas)
// ==========================================================================

import { dbInventario, dbIngresos, dbInsertInflow } from './db.js';
import { showToast, setCurrentDates } from './utils.js';
import { currentUser } from './auth.js';

export function setupInflowForm() {
    const container = document.getElementById("inflow-rows-container");
    if (!container) return;
    container.innerHTML = "";
    addInflowRow();
}

export function addInflowRow() {
    const container = document.getElementById("inflow-rows-container");
    if (!container) return;
    const rowId = "in-row-" + Date.now() + Math.random().toString(36).substring(2, 5);
    
    let optionsHTML = dbInventario.map(item => `
        <option value="${item.id}">${item.codigo} - ${item.nombre} (${item.unidad})</option>
    `).join("");

    const row = document.createElement("div");
    row.className = "dynamic-row";
    row.id = rowId;
    row.innerHTML = `
        <div class="form-group">
            <label>Seleccionar Equipo de Protección (EPP)</label>
            <select class="inflow-item-select" required>
                <option value="" disabled selected>Seleccione EPP...</option>
                ${optionsHTML}
            </select>
        </div>
        <div class="form-group">
            <label>Cantidad a Ingresar</label>
            <input type="number" class="inflow-qty-input" min="1" placeholder="0" required>
        </div>
        <button type="button" class="btn-remove btn btn-link" data-row-id="${rowId}" title="Eliminar fila">
            <i class="fa-solid fa-trash-can text-danger"></i>
        </button>
    `;
    container.appendChild(row);

    row.querySelector(".btn-remove").addEventListener("click", () => {
        removeInflowRow(rowId);
    });
}

export function removeInflowRow(rowId) {
    const rows = document.querySelectorAll("#inflow-rows-container .dynamic-row");
    if (rows.length <= 1) {
        showToast("Debe registrar al menos un EPP en la guía.", "warning");
        return;
    }
    const element = document.getElementById(rowId);
    if (element) element.remove();
}

export function resetInflowForm() {
    const form = document.getElementById("inflow-form");
    if (form) form.reset();
    setupInflowForm();
    setCurrentDates();
}

export async function saveInflow(event, switchViewCallback) {
    event.preventDefault();

    const docNum = document.getElementById("inflow-doc-number").value.trim().toUpperCase();
    const supplier = document.getElementById("inflow-supplier").value.trim();
    const date = document.getElementById("inflow-date").value;
    const comments = document.getElementById("inflow-comments").value.trim();

    const rowElements = document.querySelectorAll("#inflow-rows-container .dynamic-row");
    const items = [];

    const selectedIds = [];
    let duplicateFound = false;

    rowElements.forEach(row => {
        const select = row.querySelector(".inflow-item-select");
        const qtyInput = row.querySelector(".inflow-qty-input");
        const eppId = select.value;
        const cantidad = Number(qtyInput.value);

        if (selectedIds.includes(eppId)) {
            duplicateFound = true;
        }
        selectedIds.push(eppId);

        items.push({ eppId, cantidad });
    });

    if (duplicateFound) {
        showToast("Ha ingresado el mismo EPP en varias filas del formulario. Agrúpelas en una sola.", "danger");
        return;
    }

    const newInflow = {
        factura: docNum,
        proveedor: supplier,
        fecha: date,
        items: items,
        comentarios: comments,
        registrado_por: currentUser.nombre
    };

    try {
        showToast("Registrando guía en Supabase...", "info");
        await dbInsertInflow(newInflow);
        
        showToast(`Guía ${docNum} registrada con éxito. Stock ingresado en Supabase.`, "success");
        
        resetInflowForm();
        if (switchViewCallback) switchViewCallback("view-inventory");
    } catch (error) {
        showToast("Error al registrar guía: " + error.message, "danger");
    }
}

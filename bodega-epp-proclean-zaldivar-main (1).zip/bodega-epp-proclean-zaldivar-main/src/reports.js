// ==========================================================================
// Módulo de Historial, Logs de Auditoría y Reportes Generales
// ==========================================================================

import { dbIngresos, dbSalidas, dbInsumoMovimientos, dbInventario } from './db.js';
import { showToast } from './utils.js';
import { showVoucherDetailsById } from './outflow.js';

let historyCurrentPage = 1;
let historyPageSize = 15;
let consolidatedHistory = [];
let filteredHistory = [];

function removeAccents(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function applyHistoryFilters() {
    const searchInput = document.getElementById("history-search");
    const typeSelect = document.getElementById("history-filter-type");

    const searchQuery = searchInput ? removeAccents(searchInput.value.toLowerCase().trim()) : "";
    const filterType = typeSelect ? typeSelect.value : "";

    const searchWords = searchQuery.split(/\s+/).filter(w => w.length > 0);

    filteredHistory = consolidatedHistory.filter(mov => {
        const docText = removeAccents((mov.documento || "").toLowerCase());
        const detText = removeAccents((mov.detalles || "").toLowerCase());
        const userText = removeAccents((mov.usuario || "").toLowerCase());
        
        // Build a text of all items code & name
        const itemsText = removeAccents(mov.items.map(it => {
            if (mov.tipo === "insumo_recepcion") {
                return "insumo " + it.nombre;
            }
            const epp = dbInventario.find(i => i.id === it.eppId) || { nombre: "", codigo: "" };
            return epp.codigo + " " + epp.nombre;
        }).join(" ").toLowerCase());

        let matchesType = true;
        if (filterType === "ingreso") {
            matchesType = mov.tipo === "ingreso" || mov.tipo === "insumo_recepcion";
        } else if (filterType === "salida") {
            matchesType = mov.tipo === "salida";
        }

        const matchesSearch = searchWords.every(word => {
            return docText.includes(word) || detText.includes(word) || userText.includes(word) || itemsText.includes(word);
        });

        return matchesType && matchesSearch;
    });
}

export function renderHistoryTable() {
    const tbody = document.getElementById("history-tbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    consolidatedHistory = [];

    dbIngresos.forEach(ing => {
        consolidatedHistory.push({
            original: ing,
            tipo: "ingreso",
            fecha: new Date(ing.fecha),
            fechaStr: ing.fecha,
            documento: `Guía: ${ing.factura}`,
            detalles: ing.proveedor,
            usuario: ing.registrado_por || "Administrador Bodega",
            items: ing.items
        });
    });

    dbSalidas.forEach(sal => {
        consolidatedHistory.push({
            original: sal,
            tipo: "salida",
            fecha: new Date(sal.fecha),
            fechaStr: sal.fecha,
            documento: `Entregado a: ${sal.trabajador}`,
            detalles: `RUT: ${sal.rut} | Área: ${sal.area}`,
            usuario: sal.registrado_por || "Despacho Bodega",
            items: sal.items
        });
    });

    dbInsumoMovimientos.forEach(mov => {
        consolidatedHistory.push({
            original: mov,
            tipo: "insumo_recepcion",
            fecha: new Date(mov.fecha),
            fechaStr: mov.fecha,
            documento: `Recepción: ${mov.codigo_solicitud || mov.codigoSolicitud}`,
            detalles: `Proyecto: ${mov.mejora}`,
            usuario: mov.registrado_por || "Bodega Insumos",
            items: mov.items
        });
    });

    consolidatedHistory.sort((a, b) => b.fecha - a.fecha);

    applyHistoryFilters();

    if (filteredHistory.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No se registran movimientos en el historial.</td></tr>`;
        renderHistoryPagination();
        return;
    }

    const totalItems = filteredHistory.length;
    const totalPages = Math.ceil(totalItems / historyPageSize);
    if (historyCurrentPage > totalPages) historyCurrentPage = Math.max(1, totalPages);

    const startIndex = (historyCurrentPage - 1) * historyPageSize;
    const endIndex = Math.min(startIndex + historyPageSize, totalItems);
    const pageItems = filteredHistory.slice(startIndex, endIndex);

    pageItems.forEach(mov => {
        const itemsListHTML = mov.items.map(it => {
            if (mov.tipo === "insumo_recepcion") {
                return `<div style="font-size:0.85rem; margin-bottom: 2px;">
                    <span class="badge badge-info" style="font-size: 0.65rem; padding: 2px 6px; background-color:rgba(6, 182, 212, 0.12); color:var(--color-info); border:1px solid rgba(6,182,212,0.2);">
                        ${it.cantidad}x
                    </span> 
                    <strong>INSUMO</strong> - ${it.nombre}
                </div>`;
            }
            const epp = dbInventario.find(i => i.id === it.eppId) || { nombre: "EPP Desconocido", codigo: "???", unidad: "U" };
            return `<div style="font-size:0.85rem; margin-bottom: 2px;">
                <span class="badge badge-info" style="font-size: 0.65rem; padding: 2px 6px;">${it.cantidad}x</span> 
                <strong>${epp.codigo}</strong> - ${epp.nombre}
            </div>`;
        }).join("");

        const badgeTipo = mov.tipo === "ingreso" 
            ? `<span class="badge badge-success"><i class="fa-solid fa-cloud-arrow-up"></i> Ingreso</span>`
            : mov.tipo === "insumo_recepcion"
                ? `<span class="badge badge-info" style="background-color:rgba(6, 182, 212, 0.15); color:var(--color-info); border: 1px solid rgba(6,182,212,0.25);"><i class="fa-solid fa-boxes-packing"></i> Insumo</span>`
                : `<span class="badge badge-primary" style="background-color:rgba(224, 122, 95, 0.15); color:var(--color-primary); border: 1px solid rgba(224,122,95,0.25);"><i class="fa-solid fa-hand-holding-hand"></i> Entrega</span>`;

        const localDate = new Date(mov.fechaStr);
        const options = { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' };
        const formattedDate = localDate.toLocaleDateString('es-CL', options);

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td style="white-space: nowrap;">${formattedDate}</td>
            <td>${badgeTipo}</td>
            <td>
                <div style="font-weight: 600;">${mov.documento}</div>
                <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 2px;">${mov.detalles}</div>
            </td>
            <td>${itemsListHTML}</td>
            <td style="font-size: 0.85rem; color: var(--text-muted);">${mov.usuario}</td>
            <td>
                ${mov.tipo === "salida" 
                    ? `<button class="btn btn-secondary btn-sm val-voucher-btn" data-id="${mov.original.id}" title="Ver Vale de Entrega Firmado">
                        <i class="fa-solid fa-file-signature text-warning"></i> Vale
                       </button>`
                    : `<span style="color:var(--text-muted); font-size:0.75rem;">N/A</span>`
                }
            </td>
        `;
        tbody.appendChild(tr);
    });

    tbody.querySelectorAll(".val-voucher-btn").forEach(button => {
        button.addEventListener("click", () => {
            showVoucherDetailsById(button.dataset.id);
        });
    });

    renderHistoryPagination();
}

function renderHistoryPagination() {
    const container = document.getElementById("history-pagination");
    if (!container) return;

    const totalItems = filteredHistory.length;
    const totalPages = Math.ceil(totalItems / historyPageSize) || 1;

    if (historyCurrentPage > totalPages) {
        historyCurrentPage = totalPages;
    }

    const startItemIndex = totalItems === 0 ? 0 : (historyCurrentPage - 1) * historyPageSize + 1;
    const endItemIndex = Math.min(historyCurrentPage * historyPageSize, totalItems);

    container.innerHTML = `
        <div class="pagination-info">
            Mostrando <strong>${startItemIndex}</strong> - <strong>${endItemIndex}</strong> de <strong>${totalItems}</strong> movimientos
        </div>
        <div class="pagination-controls">
            <button type="button" class="btn btn-secondary btn-sm" onclick="changeHistoryPage(${historyCurrentPage - 1})" ${historyCurrentPage === 1 ? 'disabled' : ''}>
                <i class="fa-solid fa-chevron-left"></i>
            </button>
            <span style="font-size:0.85rem; font-weight:600; margin:0 8px;">Pág. ${historyCurrentPage} de ${totalPages}</span>
            <button type="button" class="btn btn-secondary btn-sm" onclick="changeHistoryPage(${historyCurrentPage + 1})" ${historyCurrentPage === totalPages ? 'disabled' : ''}>
                <i class="fa-solid fa-chevron-right"></i>
            </button>
        </div>
        <div class="pagination-page-size">
            <span>Mostrar</span>
            <select onchange="changeHistoryPageSize(this.value)">
                <option value="10" ${historyPageSize === 10 ? 'selected' : ''}>10</option>
                <option value="15" ${historyPageSize === 15 ? 'selected' : ''}>15</option>
                <option value="25" ${historyPageSize === 25 ? 'selected' : ''}>25</option>
                <option value="50" ${historyPageSize === 50 ? 'selected' : ''}>50</option>
            </select>
        </div>
    `;
}

export function changeHistoryPage(page) {
    historyCurrentPage = page;
    renderHistoryTable();
}

export function changeHistoryPageSize(size) {
    historyPageSize = Number(size);
    historyCurrentPage = 1;
    renderHistoryTable();
}

export function filterHistoryTable() {
    historyCurrentPage = 1;
    renderHistoryTable();
}

export function exportHistoryCSV() {
    if (dbIngresos.length === 0 && dbSalidas.length === 0) {
        showToast("No hay movimientos para exportar.", "warning");
        return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Fecha,Tipo,Documento/Guia,Receptor/Proveedor,RUT,Area,Codigo EPP,Nombre EPP,Cantidad,Unidad,Usuario\r\n";

    dbIngresos.forEach(ing => {
        const localDate = new Date(ing.fecha).toLocaleDateString('es-CL');
        ing.items.forEach(it => {
            const epp = dbInventario.find(i => i.id === it.eppId) || { nombre: "EPP Desconocido", codigo: "???" };
            const row = [
                localDate,
                "INGRESO",
                ing.factura,
                ing.proveedor,
                "", 
                "", 
                epp.codigo,
                `"${epp.nombre.replace(/"/g, '""')}"`,
                it.cantidad,
                epp.unidad || "Unidades",
                ing.registrado_por || "Administrador Bodega"
            ];
            csvContent += row.join(",") + "\r\n";
        });
    });

    dbSalidas.forEach(sal => {
        const localDate = new Date(sal.fecha).toLocaleDateString('es-CL');
        sal.items.forEach(it => {
            const epp = dbInventario.find(i => i.id === it.eppId) || { nombre: "EPP Desconocido", codigo: "???" };
            const row = [
                localDate,
                "SALIDA",
                "ACTA-ENTREGA",
                `"${sal.trabajador.replace(/"/g, '""')}"`,
                sal.rut,
                sal.area,
                epp.codigo,
                `"${epp.nombre.replace(/"/g, '""')}"`,
                it.cantidad,
                epp.unidad || "Unidades",
                sal.registrado_por || "Despacho Bodega"
            ];
            csvContent += row.join(",") + "\n";
        });
    });

    dbInsumoMovimientos.forEach(mov => {
        const localDate = new Date(mov.fecha).toLocaleDateString('es-CL');
        mov.items.forEach(it => {
            const row = [
                localDate,
                "RECEPCION_INSUMO",
                mov.codigoSolicitud,
                `"Proyecto: ${mov.mejora.replace(/"/g, '""')}"`,
                "", 
                "", 
                "INSUMO",
                `"${it.nombre.replace(/"/g, '""')}"`,
                it.cantidad,
                "Unidades",
                mov.registrado_por || "Bodega Insumos"
            ];
            csvContent += row.join(",") + "\n";
        });
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `reporte_bodega_movimientos_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Historial exportado en formato CSV.", "success");
}

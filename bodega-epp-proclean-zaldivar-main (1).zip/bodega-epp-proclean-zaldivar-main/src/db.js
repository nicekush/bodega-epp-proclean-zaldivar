// ==========================================================================
// Base de Datos Centralizada en la Nube (Supabase Client & Query Layer)
// ==========================================================================

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Estado de memoria local sincronizado
export let dbCategorias = [];
export let dbAreas = [];
export let dbTurnos = [];
export let dbInventario = [];
export let dbIngresos = [];
export let dbSalidas = [];
export let dbInsumos = [];
export let dbInsumoMovimientos = [];
export let dbSolicitudesAbastecimiento = [];

// Inicialización asíncrona desde Supabase
export async function initDatabase() {
    try {
        // 1. Cargar Categorías
        const { data: cats, error: errCats } = await supabase.from('categorias').select('nombre').order('nombre');
        if (errCats) throw errCats;
        dbCategorias = cats.map(c => c.nombre);

        // 2. Cargar Áreas
        const { data: ars, error: errArs } = await supabase.from('areas').select('nombre').order('nombre');
        if (errArs) throw errArs;
        dbAreas = ars.map(a => a.nombre);

        // 2.5 Cargar Turnos
        try {
            const { data: trns, error: errTrns } = await supabase.from('turnos').select('nombre').order('nombre');
            if (errTrns) throw errTrns;
            dbTurnos = trns.map(t => t.nombre);
        } catch (e) {
            console.warn("Tabla 'turnos' no disponible en Supabase. Usando valores por defecto.", e);
            dbTurnos = ['Turno A', 'Turno B'];
        }

        // 3. Cargar Catálogo de Inventario
        const { data: inv, error: errInv } = await supabase.from('inventario').select('*').order('codigo');
        if (errInv) throw errInv;
        dbInventario = inv;

        // 4. Cargar Ingresos (Facturas)
        const { data: ing, error: errIng } = await supabase.from('ingresos').select('*').order('fecha', { ascending: false });
        if (errIng) throw errIng;
        dbIngresos = ing;

        // 5. Cargar Salidas (Actas)
        const { data: sal, error: errSal } = await supabase.from('salidas').select('*').order('fecha', { ascending: false });
        if (errSal) throw errSal;
        dbSalidas = sal;

        // 6. Cargar Insumos para Mejoras
        const { data: ins, error: errIns } = await supabase.from('insumos_mejoras').select('*').order('fecha_solicitud', { ascending: false });
        if (errIns) throw errIns;
        dbInsumos = ins;

        // 7. Cargar Historial de Movimientos de Insumos
        const { data: mov, error: errMov } = await supabase.from('insumos_movimientos').select('*').order('fecha', { ascending: false });
        if (errMov) throw errMov;
        dbInsumoMovimientos = mov;

        // 8. Cargar Solicitudes de Abastecimiento de Bodega (con Fallback Local)
        try {
            const { data: rep, error: errRep } = await supabase.from('solicitudes_abastecimiento').select('*').order('fecha', { ascending: false });
            if (errRep) throw errRep;
            dbSolicitudesAbastecimiento = rep || [];
        } catch (e) {
            console.warn("Tabla 'solicitudes_abastecimiento' no detectada en Supabase. Usando persistencia en localStorage.");
            const localData = localStorage.getItem("db_solicitudes_abastecimiento");
            try {
                dbSolicitudesAbastecimiento = localData ? JSON.parse(localData) : [];
            } catch (parseErr) {
                dbSolicitudesAbastecimiento = [];
            }
            if (!Array.isArray(dbSolicitudesAbastecimiento)) {
                dbSolicitudesAbastecimiento = [];
            }
        }

    } catch (error) {
        console.error("Error cargando base de datos desde Supabase:", error);
        throw error;
    }
}

// ==========================================================================
// Operaciones de Escritura y Sincronización en Supabase
// ==========================================================================

// EPP / Inventario
export async function dbInsertEPP(item) {
    const { data, error } = await supabase.from('inventario').insert([{
        codigo: item.codigo,
        nombre: item.nombre,
        categoria: item.categoria,
        stock: item.stock,
        stock_minimo: item.stockMinimo,
        unidad: item.unidad,
        duracion_meses: item.duracion_meses
    }]).select();
    if (error) throw error;
    // Sincronizar localmente
    dbInventario.push(data[0]);
    return data[0];
}

export async function dbUpdateEPPStock(id, newStock) {
    const { data, error } = await supabase.from('inventario')
        .update({ stock: newStock })
        .eq('id', id)
        .select();
    if (error) throw error;
    // Sincronizar localmente
    const idx = dbInventario.findIndex(i => i.id === id);
    if (idx !== -1) dbInventario[idx].stock = newStock;
    return data[0];
}

// Categorías
export async function dbInsertCategory(nombre) {
    const { data, error } = await supabase.from('categorias').insert([{ nombre }]).select();
    if (error) throw error;
    dbCategorias.push(nombre);
    dbCategorias.sort();
    return data[0];
}

export async function dbDeleteCategory(nombre) {
    const { error } = await supabase.from('categorias').delete().eq('nombre', nombre);
    if (error) throw error;
    dbCategorias = dbCategorias.filter(c => c !== nombre);
}

// Áreas
export async function dbInsertArea(nombre) {
    const { data, error } = await supabase.from('areas').insert([{ nombre }]).select();
    if (error) throw error;
    dbAreas.push(nombre);
    dbAreas.sort();
    return data[0];
}

export async function dbDeleteArea(nombre) {
    const { error } = await supabase.from('areas').delete().eq('nombre', nombre);
    if (error) throw error;
    dbAreas = dbAreas.filter(a => a !== nombre);
}

// Ingresos (Facturas)
export async function dbInsertInflow(inflow) {
    // Insertar el ingreso
    const { data, error } = await supabase.from('ingresos').insert([{
        factura: inflow.factura,
        proveedor: inflow.proveedor,
        fecha: inflow.fecha,
        items: inflow.items,
        comentarios: inflow.comentarios,
        registrado_por: inflow.registrado_por
    }]).select();
    if (error) throw error;
    
    // Actualizar stock de los EPPs asociados en Supabase
    for (const item of inflow.items) {
        const localEPP = dbInventario.find(i => i.id === item.eppId);
        if (localEPP) {
            const nuevoStock = localEPP.stock + item.cantidad;
            await dbUpdateEPPStock(item.eppId, nuevoStock);
        }
    }
    
    dbIngresos.unshift(data[0]);
    return data[0];
}

// Salidas (Actas de Entrega)
export async function dbInsertOutflow(outflow) {
    const { data, error } = await supabase.from('salidas').insert([{
        trabajador: outflow.trabajador,
        rut: outflow.rut,
        area: outflow.area,
        fecha: outflow.fecha,
        items: outflow.items,
        firma: outflow.firma,
        registrado_por: outflow.registrado_por
    }]).select();
    if (error) throw error;

    // Descontar stock de los EPPs en Supabase
    for (const item of outflow.items) {
        const localEPP = dbInventario.find(i => i.id === item.eppId);
        if (localEPP) {
            const nuevoStock = Math.max(0, localEPP.stock - item.cantidad);
            await dbUpdateEPPStock(item.eppId, nuevoStock);
        }
    }

    dbSalidas.unshift(data[0]);
    return data[0];
}

// Insumos para Mejoras (Solicitud)
export async function dbInsertSupplyRequest(req) {
    const { data, error } = await supabase.from('insumos_mejoras').insert([{
        codigo: req.codigo,
        fecha_solicitud: req.fechaSolicitud,
        mejora: req.mejora,
        proveedor: req.proveedor,
        items: req.items,
        estado: req.estado,
        comentarios: req.comentarios,
        trabajador: req.trabajador,
        rut: req.rut,
        turno: req.turno,
        prioridad: req.prioridad,
        evidencia: req.evidencia
    }]).select();
    if (error) throw error;

    dbInsumos.unshift(data[0]);
    return data[0];
}

// Insumos para Mejoras (Recepción)
export async function dbInsertSupplyReception(mov, reqId, updatedItems, newStatus, updatedComments) {
    // 1. Registrar movimiento
    const { data: newMov, error: errMov } = await supabase.from('insumos_movimientos').insert([{
        fecha: mov.fecha,
        codigo_solicitud: mov.codigoSolicitud,
        mejora: mov.mejora,
        items: mov.items,
        comentarios: mov.comentarios,
        registrado_por: mov.registrado_por
    }]).select();
    if (errMov) throw errMov;

    // 2. Actualizar estado y cantidades de la solicitud de mejora
    const { data: updatedReq, error: errReq } = await supabase.from('insumos_mejoras')
        .update({
            items: updatedItems,
            estado: newStatus,
            comentarios: updatedComments
        })
        .eq('id', reqId)
        .select();
    if (errReq) throw errReq;

    // Sincronizar localmente
    dbInsumoMovimientos.unshift(newMov[0]);
    const idx = dbInsumos.findIndex(i => i.id === reqId);
    if (idx !== -1) {
        dbInsumos[idx].items = updatedItems;
        dbInsumos[idx].estado = newStatus;
        dbInsumos[idx].comentarios = updatedComments;
    }

    return newMov[0];
}

// Función de reinicio de BD (borra todas las transacciones pero mantiene catálogo)
export async function dbResetTransactions() {
    const { error: err1 } = await supabase.from('ingresos').delete().neq('factura', 'KEEP');
    const { error: err2 } = await supabase.from('salidas').delete().neq('trabajador', 'KEEP');
    const { error: err3 } = await supabase.from('insumos_movimientos').delete().neq('mejora', 'KEEP');
    const { error: err4 } = await supabase.from('insumos_mejoras').delete().neq('codigo', 'KEEP');
    
    if (err1 || err2 || err3 || err4) throw (err1 || err2 || err3 || err4);
    
    // Resetear stocks de catálogo a 0
    const { error: err5 } = await supabase.from('inventario').update({ stock: 0 }).neq('codigo', 'KEEP');
    if (err5) throw err5;

    await initDatabase();
}

// ==========================================================================
// Operaciones de Autenticación y Usuarios (Supabase Custom RBAC)
// ==========================================================================

export async function dbVerificarCredenciales(rut, password) {
    const { data, error } = await supabase.rpc('verificar_credenciales', {
        p_rut: rut,
        p_password: password
    });
    if (error) throw error;
    return data && data[0] ? data[0] : { success: false };
}

export async function dbObtenerUsuarios() {
    const { data, error } = await supabase
        .from('usuarios')
        .select('rut, nombre, rol, cambio_clave_pendiente, created_at')
        .order('nombre');
    if (error) throw error;
    return data;
}

export async function dbCrearUsuario(usuario) {
    // Generar el hash de la contraseña en la base de datos usando crypt de pg_crypto
    // Como Supabase JS inserta directamente objetos, podemos usar un insert raw o una RPC.
    // Para simplificar, insertamos llamando a una consulta que usa la expresión crypt en sql,
    // pero como la librería supabase-js escapa valores, la forma más limpia y segura es usar RPC
    // o insertar directamente si habilitamos una pequeña RPC auxiliar o hacemos el hash vía Postgres.
    // Vamos a crear el usuario encriptando la clave temporal.
    // Usaremos una llamada RPC en Postgres para crear usuarios de forma segura.
    const { data, error } = await supabase.rpc('crear_usuario', {
        p_rut: usuario.rut,
        p_nombre: usuario.nombre,
        p_rol: usuario.rol,
        p_password: usuario.password
    });
    if (error) throw error;
    return data;
}

export async function dbActualizarPassword(rut, nuevaPassword) {
    const { data, error } = await supabase.rpc('actualizar_password_usuario', {
        p_rut: rut,
        p_password: nuevaPassword
    });
    if (error) throw error;
    return data;
}

export async function dbEliminarUsuario(rut) {
    const { error } = await supabase
        .from('usuarios')
        .delete()
        .eq('rut', rut);
    if (error) throw error;
}

// Actualizar perfil de usuario (Nombre y Rol de forma directa)
export async function dbActualizarUsuario(rut, nombre, rol, password = null) {
    let updateData = { nombre, rol };
    
    // Si viene password, se actualiza llamando al hash de pgcrypto.
    // Para simplificar la llamada, podemos usar una RPC o actualizar directamente si la contraseña se guarda con hash.
    // Para mantener consistencia con crear_usuario, usaremos la RPC actualizar_password_usuario
    // si el admin define una clave nueva, y luego actualizaremos el nombre/rol.
    const { error } = await supabase
        .from('usuarios')
        .update(updateData)
        .eq('rut', rut);
    if (error) throw error;

    if (password && password.trim().length >= 6) {
        const { error: errPass } = await supabase.rpc('actualizar_password_usuario', {
            p_rut: rut,
            p_password: password
        });
        if (errPass) throw errPass;
    }
}


// Actualizar datos del EPP (Nombre, Categoría, Stock Mínimo, Unidad)
export async function dbUpdateEPPData(id, item) {
    const { data, error } = await supabase.from('inventario')
        .update({
            nombre: item.nombre,
            categoria: item.categoria,
            stock_minimo: item.stock_minimo,
            unidad: item.unidad
        })
        .eq('id', id)
        .select();
    if (error) throw error;
    
    // Sincronizar localmente
    const idx = dbInventario.findIndex(i => i.id === id);
    if (idx !== -1) {
        dbInventario[idx].nombre = item.nombre;
        dbInventario[idx].categoria = item.categoria;
        dbInventario[idx].stock_minimo = item.stock_minimo;
        dbInventario[idx].unidad = item.unidad;
    }
    return data[0];
}

// Eliminar EPP del catálogo
export async function dbDeleteEPP(id) {
    const { error } = await supabase.from('inventario')
        .delete()
        .eq('id', id);
    if (error) throw error;
    
    // Sincronizar localmente
    dbInventario = dbInventario.filter(i => i.id !== id);
}

// Turnos
export async function dbInsertTurno(nombre) {
    const { data, error } = await supabase.from('turnos').insert([{ nombre }]).select();
    if (error) throw error;
    dbTurnos.push(data[0].nombre);
    dbTurnos.sort();
    return data[0];
}

export async function dbDeleteTurno(nombre) {
    const { error } = await supabase.from('turnos').delete().eq('nombre', nombre);
    if (error) throw error;
    dbTurnos = dbTurnos.filter(t => t !== nombre);
}

// Solicitudes de Abastecimiento de Bodega (Pedidos de Reposición)
export async function dbInsertReplenishmentRequest(req) {
    const summaryEPP = req.items.map(it => it.nombre).join(", ").slice(0, 250);
    const totalQty = req.items.reduce((acc, it) => acc + Number(it.cantidad || 0), 0);
    const firstSku = req.items[0] ? req.items[0].sku : "-";
    const firstEppId = req.items[0] ? req.items[0].eppId : null;

    const payload = {
        codigo: req.codigo,
        fecha: req.fecha,
        epp_id: firstEppId,
        sku: firstSku,
        nombre_epp: summaryEPP,
        cantidad_solicitada: totalQty,
        cantidad_recibida: req.items.reduce((acc, it) => acc + Number(it.recibido || 0), 0),
        estado: req.estado,
        comentarios: req.comentarios,
        registrado_por: req.registrado_por,
        items: req.items
    };

    const isEdit = req.id && !req.id.startsWith("REP-TEMP-");

    try {
        let resultData;
        if (isEdit) {
            const { data, error } = await supabase.from('solicitudes_abastecimiento')
                .update(payload)
                .eq('id', req.id)
                .select();
            if (error) throw error;
            resultData = data[0];
            
            // Sincronizar localmente
            const idx = dbSolicitudesAbastecimiento.findIndex(r => r.id === req.id);
            if (idx !== -1) dbSolicitudesAbastecimiento[idx] = resultData;
        } else {
            const { data, error } = await supabase.from('solicitudes_abastecimiento').insert([payload]).select();
            if (error) throw error;
            resultData = data[0];
            dbSolicitudesAbastecimiento.unshift(resultData);
        }
        return resultData;
    } catch (e) {
        console.warn("Fallo en Supabase, procesando localmente en localStorage.", e);
        const localReq = {
            id: req.id || "REP-" + Date.now(),
            ...payload
        };
        
        if (isEdit) {
            const idx = dbSolicitudesAbastecimiento.findIndex(r => r.id === req.id);
            if (idx !== -1) dbSolicitudesAbastecimiento[idx] = localReq;
        } else {
            dbSolicitudesAbastecimiento.unshift(localReq);
        }
        localStorage.setItem("db_solicitudes_abastecimiento", JSON.stringify(dbSolicitudesAbastecimiento));
        return localReq;
    }
}

export async function dbUpdateReplenishmentStatus(id, status, updatedItems = null, comments = "") {
    let targetObj = dbSolicitudesAbastecimiento.find(r => r.id === id);
    if (!targetObj) return null;

    const finalItems = updatedItems || targetObj.items || [];
    const totalRecv = finalItems.reduce((acc, it) => acc + Number(it.recibido || 0), 0);

    const payload = {
        estado: status,
        cantidad_recibida: totalRecv,
        comentarios: comments || targetObj.comentarios,
        items: finalItems
    };

    try {
        const { data, error } = await supabase.from('solicitudes_abastecimiento')
            .update(payload)
            .eq('id', id)
            .select();
        if (error) throw error;
        
        // Sincronizar localmente
        const idx = dbSolicitudesAbastecimiento.findIndex(r => r.id === id);
        if (idx !== -1) {
            dbSolicitudesAbastecimiento[idx] = data[0];
        }

        // Si hay items recibidos en esta transacción, aumentar el stock en el inventario e insertar registro de Inflow
        if (updatedItems !== null) {
            const inflowItems = [];
            for (const item of finalItems) {
                const localEPP = dbInventario.find(i => i.id === item.eppId);
                if (localEPP) {
                    // El incremento real es la cantidad recibida en esta transacción (recibido_ahora)
                    const recvQty = Number(item.recibido_ahora || 0);
                    if (recvQty > 0) {
                        const nuevoStock = localEPP.stock + recvQty;
                        await dbUpdateEPPStock(item.eppId, nuevoStock);
                        inflowItems.push({
                            eppId: item.eppId,
                            nombre: item.nombre || localEPP.nombre,
                            cantidad: recvQty
                        });
                    }
                }
            }

            // Registrar ingreso por guía automático si hay items recibidos
            if (inflowItems.length > 0) {
                await dbInsertInflow({
                    factura: "GUIA-" + targetObj.codigo,
                    proveedor: "Soporte Operacional (Pedido)",
                    fecha: new Date().toISOString(),
                    items: inflowItems,
                    comentarios: "Ingreso automático por recepción de pedido " + targetObj.codigo + ". " + (comments || ""),
                    registrado_por: targetObj.registrado_por || "Operador"
                });
            }
        }
        return data[0];
    } catch (e) {
        console.warn("Fallo actualización en Supabase, procesando localmente en localStorage.", e);
        const idx = dbSolicitudesAbastecimiento.findIndex(r => r.id === id);
        if (idx !== -1) {
            dbSolicitudesAbastecimiento[idx].estado = status;
            dbSolicitudesAbastecimiento[idx].cantidad_recibida = totalRecv;
            dbSolicitudesAbastecimiento[idx].comentarios = comments || targetObj.comentarios;
            dbSolicitudesAbastecimiento[idx].items = finalItems;
            
            // Si hay items recibidos en esta transacción, aumentar el stock local
            if (updatedItems !== null) {
                const inflowItems = [];
                for (const item of finalItems) {
                    const localEPP = dbInventario.find(i => i.id === item.eppId);
                    if (localEPP) {
                        const recvQty = Number(item.recibido_ahora || 0);
                        if (recvQty > 0) {
                            const nuevoStock = localEPP.stock + recvQty;
                            const eppIdx = dbInventario.findIndex(i => i.id === item.eppId);
                            if (eppIdx !== -1) dbInventario[eppIdx].stock = nuevoStock;
                            
                            inflowItems.push({
                                eppId: item.eppId,
                                nombre: item.nombre || localEPP.nombre,
                                cantidad: recvQty
                            });
                        }
                    }
                }

                // Sincronización local del inflow automático
                if (inflowItems.length > 0) {
                    const localInflow = {
                        id: "INF-" + Date.now(),
                        factura: "GUIA-" + targetObj.codigo,
                        proveedor: "Soporte Operacional (Pedido)",
                        fecha: new Date().toISOString(),
                        items: inflowItems,
                        comentarios: "Ingreso automático por recepción de pedido " + targetObj.codigo + ". " + (comments || ""),
                        registrado_por: targetObj.registrado_por || "Operador"
                    };
                    // Asegurar que dbIngresos esté importado o disponible
                    if (typeof dbIngresos !== "undefined" && dbIngresos.unshift) {
                        dbIngresos.unshift(localInflow);
                    }
                }
            }
        }
        localStorage.setItem("db_solicitudes_abastecimiento", JSON.stringify(dbSolicitudesAbastecimiento));
        return dbSolicitudesAbastecimiento[idx];
    }
}

export async function dbUpdateWorkerProfile(rut, data) {
    const { error } = await supabase.from('salidas')
        .update({
            trabajador: data.trabajador,
            area: data.area,
            turno: data.turno
        })
        .eq('rut', rut);
    if (error) {
        console.warn("Fallo actualización de trabajador en Supabase, procesando localmente.", error);
    }

    // Sincronizar en memoria y localStorage
    dbSalidas.forEach(s => {
        if (s.rut === rut) {
            s.trabajador = data.trabajador;
            s.area = data.area;
            s.turno = data.turno;
        }
    });
    localStorage.setItem("db_salidas", JSON.stringify(dbSalidas));
}



